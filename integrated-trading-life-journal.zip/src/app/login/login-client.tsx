"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Activity, BookOpenText, Globe2, ShieldCheck } from "lucide-react";
import { FirebaseError } from "firebase/app";
import { Logo, ThemeToggle } from "@/components/app-shell";
import { consumeRedirectResult, signInWithGoogle, SignInCancelled } from "@/lib/firebase";

function GoogleMark() {
  return (
    <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" aria-hidden>
      <path fill="#4285F4" d="M23.5 12.27c0-.85-.08-1.66-.22-2.45H12v4.64h6.45a5.52 5.52 0 0 1-2.39 3.62v3h3.87c2.26-2.09 3.57-5.16 3.57-8.81Z" />
      <path fill="#34A853" d="M12 24c3.24 0 5.96-1.07 7.94-2.91l-3.87-3c-1.08.72-2.45 1.15-4.07 1.15-3.13 0-5.78-2.11-6.73-4.96H1.29v3.1A12 12 0 0 0 12 24Z" />
      <path fill="#FBBC05" d="M5.27 14.28a7.2 7.2 0 0 1 0-4.56v-3.1H1.29a12 12 0 0 0 0 10.76l3.98-3.1Z" />
      <path fill="#EA4335" d="M12 4.76c1.76 0 3.35.6 4.59 1.8l3.44-3.44A11.98 11.98 0 0 0 12 0 12 12 0 0 0 1.29 6.62l3.98 3.1C6.22 6.87 8.87 4.76 12 4.76Z" />
    </svg>
  );
}

const FEATURES = [
  { icon: Activity, label: "Live prices, 5 markets" },
  { icon: BookOpenText, label: "Trades + life in one journal" },
  { icon: Globe2, label: "US · India · FX · Crypto · Gold" },
  { icon: ShieldCheck, label: "Private by default" },
];

const EASE = [0.22, 1, 0.36, 1] as const;

function friendlyError(e: unknown): string {
  if (e instanceof FirebaseError) {
    switch (e.code) {
      case "auth/unauthorized-domain":
        return "This domain isn't whitelisted yet — add it under Firebase Console → Auth → Authorized domains.";
      case "auth/operation-not-allowed":
        return "Google provider is disabled — enable it in Firebase Console → Auth → Sign-in method.";
      case "auth/network-request-failed":
        return "Network hiccup reaching Google. Check your connection and retry.";
      case "auth/too-many-requests":
        return "Too many attempts. Give it a minute and try again.";
      default:
        return `Google sign-in failed (${e.code.replace("auth/", "")}).`;
    }
  }
  return e instanceof Error ? e.message : "Something went wrong. Please try again.";
}

export function LoginClient() {
  const router = useRouter();
  const [phase, setPhase] = useState<"idle" | "google" | "exchange" | "redirecting">("idle");
  const [error, setError] = useState<string | null>(null);
  const busy = phase !== "idle";

  const exchange = useCallback(
    async (idToken: string) => {
      setPhase("exchange");
      const res = await fetch("/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ idToken }),
      });
      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        throw new Error(json.error ?? "Sign-in verification failed.");
      }
      router.replace("/");
      router.refresh();
    },
    [router]
  );

  // Complete a redirect flow if Google just sent us back here.
  useEffect(() => {
    let dead = false;
    consumeRedirectResult()
      .then((token) => {
        if (dead || !token) return;
        exchange(token).catch((e) => {
          if (!dead) {
            setError(friendlyError(e));
            setPhase("idle");
          }
        });
      })
      .catch((e) => {
        if (!dead) setError(friendlyError(e));
      });
    return () => {
      dead = true;
    };
  }, [exchange]);

  const signIn = async () => {
    setError(null);
    setPhase("google");
    try {
      const idToken = await signInWithGoogle();
      await exchange(idToken);
    } catch (e) {
      if (e instanceof SignInCancelled) {
        setPhase("idle");
        return;
      }
      setError(friendlyError(e));
      setPhase("idle");
    }
  };

  const label =
    phase === "google"
      ? "Waiting for Google…"
      : phase === "exchange"
        ? "Opening your journal…"
        : "Continue with Google";

  return (
    <div className="relative z-10 flex min-h-dvh flex-col">
      <div className="absolute right-4 top-4"><ThemeToggle /></div>

      <div className="flex flex-1 flex-col items-center justify-center px-5 py-14">
        <motion.div
          initial={{ scale: 0.7, opacity: 0, rotate: -12 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          transition={{ type: "spring", bounce: 0.35, duration: 0.8 }}
        >
          <Logo size={54} />
        </motion.div>

        <motion.h1
          initial={{ y: 18, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.12, duration: 0.6, ease: EASE }}
          className="mt-6 text-center font-display text-[34px] font-semibold leading-[1.08] tracking-[-0.03em] sm:text-[44px]"
        >
          Your trades.
          <br />
          Your days. <span className="text-brand">One journal.</span>
        </motion.h1>

        <motion.p
          initial={{ y: 16, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.22, duration: 0.6, ease: EASE }}
          className="mt-4 max-w-[380px] text-center text-[14.5px] leading-relaxed text-sub"
        >
          Log the market moves and the life between them — with live prices
          across US stocks, India, forex, crypto and gold.
        </motion.p>

        <motion.div
          initial={{ y: 16, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.32, duration: 0.6, ease: EASE }}
          className="mt-9 flex w-full max-w-[320px] flex-col items-center gap-3"
        >
          <button
            onClick={signIn}
            disabled={busy}
            className="group relative flex h-12 w-full items-center justify-center gap-3 rounded-full border border-linestrong bg-card text-[14.5px] font-medium shadow-[var(--shadow)] transition-all hover:shadow-lg active:scale-[0.98] disabled:opacity-70 cursor-pointer"
          >
            {busy ? (
              <motion.span
                className="h-[18px] w-[18px] rounded-full border-2 border-line border-t-brand"
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 0.7, ease: "linear" }}
              />
            ) : (
              <GoogleMark />
            )}
            {label}
          </button>
          {error && (
            <motion.p
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-[300px] text-center text-[12px] leading-relaxed text-down"
            >
              {error}
            </motion.p>
          )}
          <p className="text-center text-[11.5px] leading-relaxed text-faint">
            Secured by Firebase Auth · We only ever see your name, email and photo.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-12 grid max-w-[520px] grid-cols-2 gap-2.5 sm:grid-cols-4"
        >
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.label}
              initial={{ y: 14, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 + i * 0.08, duration: 0.5, ease: EASE }}
              className="flex flex-col items-center gap-2 rounded-2xl border border-line bg-card px-3 py-4 text-center"
            >
              <f.icon className="h-4 w-4 text-brand" />
              <span className="text-[11px] font-medium leading-tight text-sub">{f.label}</span>
            </motion.div>
          ))}
        </motion.div>
      </div>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.7 }}
        className="pb-6 text-center text-[11px] text-faint"
      >
        Quill — a journal that trades as hard as you do.
      </motion.p>
    </div>
  );
}
